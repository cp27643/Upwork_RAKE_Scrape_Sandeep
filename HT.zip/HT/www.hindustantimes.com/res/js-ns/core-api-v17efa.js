 // Core API


var isClick=false;
$(function () {
	"use strict";
	
	$('img.lazy').lazy({ effect: "fadeIn", effectTime: 20, threshold: 200, failurelimit: 0 });
	
	$(window).scroll(function () {
	var scrollCount = $(".story-highlight").height()+$(".header-wrapper").height();
	var storyHeight=  $(".story-content").height();
	var storyDHeight=  $(".story-details").height();
	
	var socialHeight = $(".social-icons-ar").height();
	var Tbdyheight = storyHeight + scrollCount-socialHeight-70;
	var distanceFromTop = $(document).scrollTop();
	//alert(distanceFromTop);
	
	
	
	if ($(window).scrollTop()>scrollCount) 
	{
		
		$('.social-icons-ar').addClass('social-fixed');
					
					
	}
	
	else
	{
		
		$('.social-icons-ar').removeClass('social-fixed');
					
					
	}
	
	
	if (distanceFromTop > Tbdyheight) 
	{			
			$('.social-icons-ar').addClass('social-fix-none');
	}
	else 
	{
			$('.social-icons-ar').removeClass('social-fix-none');
	}
	
	if(storyDHeight<socialHeight)
		
	{
	
	$(".story-details").css("min-height",socialHeight+"px");
	}


});
	// 2nd nav //
	$(window).scroll(function () {
		
			if ($(this).scrollTop() > 1650) {
				$('.pre-election-nav').addClass("fixed-secondnav");
			}
			else {
				
				$('.pre-election-nav').removeClass("fixed-secondnav");
			}
			
	});
	
	$(window).scroll(function () {
		
		if ($(this).scrollTop() > 121) {
			
			$('.ipl-top-nav').addClass("fixed-iplnav");
			
		}
		else {
			
			$('.ipl-top-nav').removeClass("fixed-iplnav");
		}
		
	});
	
		$(window).scroll(function () {
		
		
		if ($(this).scrollTop() > 171) {
			
			$('.htls-nav').addClass("fixed-htlsnav");
			$('.htls-lg-logo').hide();
			$('.htls-sm-logo').show();
		}
		else {
			
			$('.htls-nav').removeClass("fixed-htlsnav");
			
			$('.htls-sm-logo').hide();
			$('.htls-lg-logo').show();
		}
		
	});
	
	//candidate slider //
	$('#candidate-slider-up').owlCarousel({ 
	items: 5,
	loop: true,
	center: false,
	margin: 20,
	lazyLoad:false,
	callbacks: true,
	nav:true,
	URLhashListener: true,
	autoplay:false,
	autoplayTimeout:3000,
	//autoplayHoverPause: true,
	startPosition: 'URLHash'            
	});
	$('#didyounow-slider-up').owlCarousel({
		  margin:10,
		  loop:true,
		  dots: true,
		  navText: [ 'PREVIOUS', 'NEXT' ],
		  nav: true,
		  items: 1
		});
	$("#select-year-up").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".party-list-prev-up").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $("party-list-prev-up").hide();
            }
        });
		}).change();

	$('a[href="#uttarpradesh"]').on('shown.bs.tab', function (e) {
	$('#candidate-slider-up').owlCarousel({ 
		items: 5,
		loop: true,
		center: false,
		margin: 20,
		lazyLoad:false,
		callbacks: true,
		nav:true,
		URLhashListener: true,
		autoplay:false,
		autoplayTimeout:3000,
		//autoplayHoverPause: true,
		startPosition: 'URLHash'          
		});
	$('didyounow-slider-up').owlCarousel({
		  margin:10,
		  loop:true,
		  dots: true,
		  navText: [ 'PREVIOUS', 'NEXT' ],
		  nav: true,
		  items: 1
		});
		$("#select-year-up").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".party-list-prev-up").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $("party-list-prev-up").hide();
            }
        });
		}).change();
	});
	
	
	$('a[href="#uttarakhand"]').on('shown.bs.tab', function (e) {
	$('#candidate-slider-uk').owlCarousel({ 
		items: 5,
		loop: true,
		center: false,
		margin: 20,
		lazyLoad:false,
		callbacks: true,
		nav:true,
		URLhashListener: true,
		autoplay:false,
		autoplayTimeout:3000,
		//autoplayHoverPause: true,
		startPosition: 'URLHash'          
		});
	$('#didyounow-slider-uk').owlCarousel({
		  margin:10,
		  loop:true,
		  dots: true,
		  navText: [ 'PREVIOUS', 'NEXT' ],
		  nav: true,
		  items: 1
		});
	$("#select-year-uk").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".party-list-prev-uk").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".party-list-prev-uk").hide();
            }
        });
    }).change();
	});
	 $('a[href="#punjab"]').on('shown.bs.tab', function (e) {
	$('#candidate-slider-punjab').owlCarousel({ 
		items: 5,
		loop: true,
		center: false,
		margin: 20,
		lazyLoad:false,
		callbacks: true,
		nav:true,
		URLhashListener: true,
		autoplay:false,
		autoplayTimeout:3000,
		//autoplayHoverPause: true,
		startPosition: 'URLHash'          
		});
	$('#didyounow-slider-punjab').owlCarousel({
		  margin:10,
		  loop:true,
		  dots: true,
		  navText: [ 'PREVIOUS', 'NEXT' ],
		  nav: true,
		  items: 1
		});
	$("#select-year-punjab").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".party-list-prev-punjab").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".party-list-prev-punjab").hide();
            }
        });
    }).change();
	 });
	 $('a[href="#manipur"]').on('shown.bs.tab', function (e) {
	$('#candidate-slider-manipur').owlCarousel({ 
		items: 5,
		loop: true,
		center: false,
		margin: 20,
		lazyLoad:false,
		callbacks: true,
		nav:true,
		URLhashListener: true,
		autoplay:false,
		autoplayTimeout:3000,
		//autoplayHoverPause: true,
		startPosition: 'URLHash'          
		});
	$('#didyounow-slider-manipur').owlCarousel({
		  margin:10,
		  loop:true,
		  dots: true,
		  navText: [ 'PREVIOUS', 'NEXT' ],
		  nav: true,
		  items: 1
		});
		$("#select-year-manipur").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".party-list-prev-manipur").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".party-list-prev-manipur").hide();
            }
        });
    }).change();
	 });
	$('a[href="#goa"]').on('shown.bs.tab', function (e) {
	$('#candidate-slider-goa').owlCarousel({ 
		items: 5,
		loop: true,
		center: false,
		margin: 20,
		lazyLoad:false,
		callbacks: true,
		nav:true,
		URLhashListener: true,
		autoplay:false,
		autoplayTimeout:3000,
		//autoplayHoverPause: true,
		startPosition: 'URLHash'          
		});
	$('#didyounow-slider-goa').owlCarousel({
		  margin:10,
		  loop:true,
		  dots: true,
		  navText: [ 'PREVIOUS', 'NEXT' ],
		  nav: true,
		  items: 1
		});
		$("#select-year-goa").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".party-list-prev-goa").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".party-list-prev-goa").hide();
            }
        });
		}).change();
	});
	
	
	
 



	
	// select-contituency
	$("#select-contituency").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".constituency-result").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".constituency-result").hide();
            }
        });
    }).change();
	
	

//do you know campian trophy
	
	$('#didyounow-campian-trophy').owlCarousel({
		  margin:10,
		  loop:true,
		  autoplay:true,
		  autoplayHoverPause:true,
		  dots: true,
		  navText: [ 'PREV', 'NEXT' ],
		  nav: true,
		  items: 1
		});
	
	
	
	
	
	
	
	
	
	
	
	//Sticky Header_______________________________________________
	$(window).scroll(function () {
		// Sticky function
		if ($(window).width() < 991) {
			if ($(this).scrollTop() > 250) {
				$('body').addClass("sticky");
				//$('.footer-wrapper').show();
			
			}
			else {
				$('body').removeClass("sticky");
				//$('.footer-wrapper').hide();
			}
		}
		if ($(window).width() > 991) {
			if ($(this).scrollTop() > 150) {
				$('body').addClass("sticky");
				//$('.footer-wrapper').show();
			}
			else {
				$('body').removeClass("sticky");
				//$('.footer-wrapper').hide();
			}
		}

		
		if ($(this).scrollTop() <= 800) {
			$('.ajax-loader1').removeClass('ajax-loader');
			$('.footprit-step').removeClass('footprit-blink');
			//$('.social-icons-ar').removeClass('social-fixed');
			$( ".foot-jump .follow-st" ).hide();
		}

	});

	
	//Story page's social icons margin calculate _____________________________________
	$(window).scroll(function () {
		var distanceFromTop = $(document).scrollTop();
		var brdcumbHeight = $('.story-content').height();
		var headingHeight = $('.header-wrapper').height();
	
		var Tbdyheight = brdcumbHeight + headingHeight;

	});

	//Active Class add/remove on  Menu_____________________________________
	$(".menu-list li .sub-menu-dt").hover(function() {
		$(this).parents(".menu-list > li").children().toggleClass('active');
		
	});
	
	

	//smooth scroll_______________________________________________
	$(".smoothscroll").click(function (e) {
		e.preventDefault();
		$("body, html").animate({
			scrollTop: $($(this).attr('href')).offset().top - 85 + "px"
		}, 600);
	});

	//popover text_______________________________________________
	$('[data-toggle="popover"]').popover();

	//Search text_______________________________________________
	$('.search-btn').on('click', function () {
		$('.search-pnl').toggleClass('expanded');
        $('.search-pnl.expanded').focus();        
	});  
    
    
    $(document).on('click','.search-btn-none', function(){
		$('.search-pnl').toggleClass('expanded');
        $('.search-pnl.expanded').focus();
    });
    
    $('.search-pnl').keyup(function(){ 
    if($(this).val().length)
    $('.search-btn').removeClass().addClass('search-btn-none');
        else
        $(".search-btn-none").removeClass().addClass('search-btn');
    });

	//Header weather toggle hide/show______________________________
	$('.weather-drop').on('click', function () {
		$('.weather-area').slideToggle();
		$('.overlay-bg, .arrow-ico').toggleClass('active');
	});

	//Header Menu Overlay background hide/show______________________________
	$(".menu-tool-pnl").on('shown.bs.dropdown', function () {
		$('.overlay-bg').addClass('active');
	});
	
	

	$(".menu-tool-pnl").on('hidden.bs.dropdown', function () {
		$('.overlay-bg').removeClass('active');
	});
    
    $(".overlay-bg").on('click', function () {
		$('.sub-menu-dt, .weather-area, .dropdown-menu').hide();
        $(".overlay-bg").hide();
	});

	//Cities toggle hide/show______________________________
	$('.column-head .dropdown').on('click', function () {
		$(this).children().find('.arrow-ico').toggleClass('active');
	});

	//Custom Select Script_______________________________________________
	$(".modal-body select , .top-navbar select , .loc-search select, .sort-by select, .business-add select, select").select2({
		minimumResultsForSearch: -1
	});

	//Select2 Script_______________________________________________
	$(".sort-by-cd select").select2();

	//Menu hide/show Script_______________________________________________
	$(".hamburger").click(function () {
		$('.nav-area').animate({left: 0}, 'fast');
	});

	$(".close-btn a").click(function () {
		$('.nav-area').animate({left: -300}, 'fast');
	});


	//Comment box focus function in story page_________________________________
	$(".fore-text-area").focus(function(){
		$(this).animate({ height: "120px" }, 500);
		$('.characters-remaining, .pd-follow-btn').show();
	});

	$(".fore-text-area").focusout(function(){
		$(this).animate({ height: "62px" }, 500);
		$('.characters-remaining, .pd-follow-btn').hide();
	});

	//Characters remaining function in story page_________________________________
	var text_max = 99;
	$('.characters-remaining .para-txt').html(text_max + ' characters remaining');

	$('.fore-text-area').keyup(function() {
		var text_length = $('.fore-text-area').val().length;
		var text_remaining = text_max - text_length;
		$('.characters-remaining .para-txt').html(text_remaining + ' characters remaining');
	});

	//Sign in / sign up Script_______________________________________________
	$(".signin-action").click(function () {
		$('.signin-form').hide();
		$('.signup-form').show();
		$(".register-head .headingfour").replaceWith("<div class='headingfour'>Sign Up</div>");
	});

	//Signup action
	$(".signup-action").click(function () {
		$('.signin-form').show();
		$('.signup-form').hide();
		$(".register-head .headingfour").replaceWith("<div class='headingfour'>Log In</div>");
	});

	//Reset password action
	$(".reset-forget-btn").click(function () {
		$('.forget-password-bx').hide();
		$('.register-info').show();
		$(".register-head .headingfour").replaceWith("<div class='headingfour'>Log In</div>");
	});

	//Forget password action
	$(".forget-ps").click(function () {
		$('.forget-password-bx').show();
		$('.register-info').hide();
		$(".register-head .headingfour").replaceWith("<div class='headingfour'>Forgot Password</div>");
	});


	//Author page tostr Script_______________________________________________
	$('.pd-follow-btn').click(function() {
		var authorName = $(this).closest('.authors-pro-about').find('.headingthree').text();
		if($(this).text() == 'Follow'){
			if($(this).hasClass('signin-first')) {
				var template = '<a href="signin.html">Login</a>/ <a href="signup.html">Signup</a> ';
				toastr.error(template +' to follow');
			}
			else {
				$(this).text('Following');
				$(this).addClass('active');
				console.log(name);
				// Display a success toast, with a title
				toastr.success('You are now following <a href="author-details.html">' + authorName+ '</a>');
			}
		}
		else if($(this).text() == 'Following'){
			$('#unfollowConfirm').modal('show');
			var that = $(this);
			$(document).on("click", "#unfollowConfirm .btn-default", function(e) {
				that.text('Follow');
				that.removeClass('active');
				// Display a success toast, with a title
				toastr.error('You unfollowed <a href="author-details.html">' + authorName + '</a>');
			});
		}
	});

	//toastr settings
	toastr.options = {
		"closeButton": false,
		"debug": false,
		"newestOnTop": false,
		"progressBar": false,
		"positionClass": "toast-top-full-width",
		"preventDuplicates": false,
		"onclick": null,
		"showDuration": "300",
		"hideDuration": "100",
		"timeOut": "2000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "fadeOut"
	};

	//Humburger Script_______________________________________________
	$(".menu-list > li .icon").next(".hidden").hide();
	$(".menu-list > li .icon").click(function () {
		var submenuid = $(this).next(".ns-megamenu").attr('id');		
		var subcontentid = '#' + submenuid + $(this).closest("li").index();
		if ($('#' + submenuid).is(':empty'))
		{			
		$('#' + submenuid).html($(subcontentid).html());	
		isClick=true;
		}
		
		$('.active').not(this).toggleClass('active').next('.ns-megamenu').children('.sub-menu-open').slideToggle().parents('li').toggleClass('select-menu');		
		$(this).toggleClass('active').next('.ns-megamenu').children('.sub-menu-open').slideToggle().parents('li').toggleClass('select-menu');
		
	});
	
	
	
	
	//Section Close on other side click Script_______________________________________________
	$(document).on("click", function (e) {
		var p = $(e.target).closest('.main-nav, .menu-tool-pnl ').length;
		if (!p) {
			$(".search-pnl.expanded").removeClass('expanded').val();
            $(".search-btn-none").removeClass().addClass('search-btn');
            $(".search-pnl").focus(function() {
              this.value = "";
            });
		}

		var q = $(e.target).closest('.weather-drop, .weather-area, .menu-list, .overlay-bg').length;
		if (!q) {
			$(".weather-area").hide();
			$(".weather-drop span.arrow-ico, .overlay-bg").removeClass('active');
		}

		if ($(window).width() <= 991) {
			var p1 = $(e.target).closest('.hamburger, .nav-area ').length;
			if (!p1) {
				$(".nav-area").animate({left: -300}, 'fast');
			}
		}
	});

	//Signin page height Script_______________________________________________
	$(window).load(function(){
		//get the width of the parent
		var parent_height = $('.header-wrapper').height();
		var window_height = $( window ).height();
		//var inner_page_height = $('.user-register-form').height();
		var inner_height = (window_height - parent_height - 40);
		//center it
		$('.user-register-form').css( 'height' , inner_height);
	});


	//Humburger Script_______________________________________________
	if ($(window).width() >= 991) {
		$(".menu-list li").hover(
			function() { 
				$(".overlay-bg").addClass('active');
				var submenuid = $(this).children(".ns-megamenu").attr('id');
				var subcontentid = '#' + submenuid + $(this).index();
				$('#' + submenuid).html($(subcontentid).html());
				
			}, function() {
				$(".overlay-bg").removeClass('active');
			});
			
			
			$(".menu-list li.jaagore").hover(
			function() { 
				$(".overlay-bg").removeClass('active');
				
			});
			
			$(".menu-list li.ipl-counter").hover(
			function() { 
				$(".overlay-bg").removeClass('active');
				
			});
	}


    //TRENDING NEWS slider_______________________________________________
	$(".smallcard-slider").owlCarousel({
		loop:true,
		margin:30,
		slideSpeed : 300,
		lazyLoad:true,
        items:3,
        nav:true,
        slideBy: 3,
		responsiveClass:true,
         URLhashListener: false,
		responsive:{
			768:{
				items:2,
				nav:true
			},
			992:{
				items:2,
				nav:true
			},
			1200:{
				items:3,
				nav:true
			}
		}
	});
	



	//Sports Slider_______________________________________________
	$('#score-slider1').owlCarousel({
		items: 1,
		loop: true,
		center: true,
		margin: 0,
		callbacks: true,
		nav:true,
		URLhashListener: true,
		autoplay:true,
		autoplayTimeout:3000,
		//autoplayHoverPause: true,
		startPosition: 'URLHash'          
	});
    
		
	
    
    //Entertainment & Story page Slider_______________________________________________
	var owl_section = $('#banner-slider').owlCarousel({
		items: 1,
		loop: true,
		center: true,
		margin: 0,
		callbacks: true,
		nav:true,
		URLhashListener: true,
		autoplay:true,
		autoplayTimeout:3000,
		//autoplayHoverPause: true,
		startPosition: 'URLHash'          
	});
	owl_section.on('changed.owl.carousel',function(property){
		var current = property.item.index;
		var src = $(property.target).find(".owl-item").eq(current).find(".item").attr('data-hash');
		var hash_src = src;
       //alert(hash_src);
		var $active_hash = $(property.target).next('.banner-thumbs').find('a[id='+hash_src+']').addClass('active');
		$('.banner-thumbs li a').not($active_hash).removeClass('active');   
     
	});
	 //Fifa Slider_______________________________________________
	var owl = $('#fifa-banner-slider').owlCarousel({
		items: 1,
		loop: true,
		center: true,
		margin: 0,
		callbacks: true,
		nav:true,
		URLhashListener: true,
		autoplay:true,
		autoplayTimeout:6000,
		//autoplayHoverPause: true,
		startPosition: 'URLHash'          
	});
	// jQuery method on
	owl.on('changed.owl.carousel',function(property){
		var current = property.item.index;
		var src = $(property.target).find(".owl-item").eq(current).find(".item").attr('data-hash');
		var hash_src = src;
       //alert(hash_src);
		var $active_hash = $(property.target).next('.banner-thumbs').find('a[id='+hash_src+']').addClass('active');
		$('.banner-thumbs li a').not($active_hash).removeClass('active');   
     
	});
            
  	

    //Tooltip_______________________________________________
    $('[data-toggle="tooltip"]').tooltip();

	//Image color picker_______________________________________________
	$('.get-color').primaryColor({
		callback: function(color) {
			$(this).parents('.image-col').css('background-color', 'rgb('+color+')');
		}
	});
    
    
    //Photo Gallery Script_______________________________________________
	// This triggers after each slide change
	$('.carousel').on('slid.bs.carousel', function () {  
		var photoLink=window.location.href;
		var carouselData = $(this).data('bs.carousel');
		var currentIndex = $('.photogallerypopupwindow div.active').index();
		var total = carouselData.$items.length;
        // Now display this wherever you want
		var text = (currentIndex + 1) + " of " + total;
		$('#carousel-index').text(text);
		var activeImg  = $('.photogallerypopupwindow div.active').find('img');
		var title = activeImg.attr('alt');
		var src = activeImg.attr('src');
		self.COMSCORE && COMSCORE.beacon({
	        c1: "2",
	        c2: "6035286"
	    });
	    $.ajax({
	        url: '/res/comscore-gallery.xml',
	        cache: false,
	        type: 'get',
	        success: function(data) {
	            //console.log(data);                
	        }
	    });
	    ga('send', { 'hitType': 'pageview', 'page': src, 'title': title });
		dataLayer.push ({ 'event' : 'send pageview', 'document_location' : photoLink, 'page_title' : title,'document_page' : src });
	});
    
    // Bootstrap slider - conditional prev next controls
    $('.carousel').carousel({
        interval: false,
        wrap: false,
    });
    
    $('#carousel-example-generic').on('slid.bs.carousel', checkitem);
    $('.left').hide();
    function checkitem()                        // check function
    { 
    	var $this = $('#carousel-example-generic');
        if ($('.carousel-inner .item:first').hasClass('active')) {
            $this.children('.left.carousel-control').hide();
        } else if ($('.carousel-inner .item:last').hasClass('active')) {
            $this.children('.right.carousel-control').hide();
        } else {
            $this.children('.carousel-control').show();

        }
    }
    
      $(".carousel").swipe({

        swipe: function(event, direction, distance, duration, fingerCount, fingerData) {

            if (direction == 'left') $(this).carousel('next');
            if (direction == 'right') $(this).carousel('prev');

        },
        allowPageScroll:"vertical"

    }); 
	
 

	// Back to Top_______________________________________________
	var offset = 300,
		//browser window scroll (in pixels) after which the "back to top" link opacity is reduced
		offset_opacity = 1200,
		//duration of the top scrolling animation (in ms)
		scroll_top_duration = 700,
		//grab the "back to top" link
		$back_to_top = $('.td-top');

	//hide or show the "back to top" link
	$(window).scroll(function(){
		if($(this).scrollTop() > offset ){
			$back_to_top.addClass('td-is-visible');
		}
		else{
			$back_to_top.removeClass('td-is-visible td-fade-out');			
		}
		
		if( $(this).scrollTop() > offset_opacity ) { 
			$back_to_top.addClass('td-fade-out');		
		}
	});

	//smooth scroll to top
	$back_to_top.on('click', function(event){
		event.preventDefault();
		$('body,html').animate({
			scrollTop: 0 ,
		 	}, scroll_top_duration
		);
	});


});

/*//Weather_______________________________________________
$(document).ready(function() {
	$.simpleWeather({
		location: 'delhi, India',
		woeid: '',
		unit: 'c',
		success: function(weather) {
			html = '<div class="headingtwo"><i class="icon-'+weather.code+'"></i> '+weather.temp+'&deg;</div>';
			html += '<span>'+weather.city+',</span>';

			$("#weather, #weather_dt").html(html);
		},
		error: function(error) {
			$("#weather, #weather_dt").html('<p>'+error+'</p>');
		}
	});
});*/


//Story page comments hide/show script_______________________________________________
$(document).ready(function () {
	var size_li = $("#comments-list > li").size();
	var x=3;
	$('#comments-list > li:lt('+x+')').show();
	$('#loadMore').click(function () {
		x= (x+5 <= size_li) ? x+5 : size_li;
		$('#comments-list > li:lt('+x+')').fadeIn();
		$('#showLess').show();
		$("#loadMore").hide();
	});
	$('#showLess').click(function () {
		x=(x-5<0) ? 3 : x-5;
		$('#comments-list > li:lt('+x+')').show();
		$('#comments-list > li').not(':lt('+x+')').fadeOut();
		$("#loadMore").show();
		$('#showLess').hide();
	});
	
	
});

function videoCallFunction(uuid,host) {
    function callDataForVideo(feedurl, uuid) { 
	        $.ajax({
	            url: feedurl,
	            dataType: 'json',
	            success: function(data) { 
	                GenerateDataForVideo(data, uuid);
	            },
	            error: function(jqXHR, exception) { 
	                console.log('error');
	            }
	        });  
	    }   
	    function GenerateDataForVideo(data, uuid) { 
	        var str = '';
	        localStorage.setItem('obj' + uuid, JSON.stringify(data));
	        str +='';
	        $.each(data.content.sectionItems, function(i, item) {
	        	var seclection_id_headline=uuid+'-videoHeadline';
		        $('#'+ seclection_id_headline ).text(item.headLine);
	        	str +='<div class="latest-videos-ar">';
	        	str +=item.videoScript;
	        	str +='<div class="para-txt">' +item.shortDescription +'</div>';
	        	str +='<div class="follow-bx">';
	        	str +='<a href="javascript:void(0)"><i class="icons tw-ico" onclick="sharePage(\'https://twitter.com/share?url='+item.websiteURL+'&text='+item.headLine+' via @htTweets\',500,600);" title="Tweet"></i> </a>';
	        	str +='<a href="javascript:void(0)"><i class="icons fb-ico" onclick="sharePage(\'http://www.facebook.com/sharer/sharer.php?u='+item.websiteURL+'\',400,350);" title="Facebook Share"></i> </a>'; 
	        	str +='<a href="javascript:void(0)"><i class="icons gplus-ico" onclick="sharePage(\'https://plus.google.com/share?url='+item.websiteURL+'\',500,450);" title="Google Plus Share"></i> </a>'; 
	        	str +='<a href="javascript:void(0)"><i class="icons instagram-ico" onclick="sharePage(\'https://www.linkedin.com/shareArticle?mini=true&url='+item.websiteURL+'&title=&summary=&source=\',600,600);" title="Linkdin Share"></i></a>';
				str +='</div>';
				str +='</div>';
	        });
	        var seclection_id=uuid+'-videoPpopupWindow';
	        $('.'+ seclection_id ).empty();
	        $('.'+ seclection_id ).append(str);  
	    }
	    callDataForVideo(
	    		host+'/Fragment/PortalConfig/Common/modules/mobile/s1/phone/controller/singleObject/getSingleVideoScript.jpt?uuid='+uuid+'',
	        uuid);
	  
}

function galleryCallFunction1(uuid,host) { 
	//var slideIndex=$('.current-slide').text();
	var activeDiv  = $('.owl-stage  div.active').find('.current-slide').text();
	var slideIndex=activeDiv;
	//alert('slideIndex: '+ slideIndex);
	function callData(feedurl, uuid) {
	        $.ajax({
	            url: feedurl,
	            dataType: 'json',
	            success: function(data) {
	                GenerateData(data, uuid,slideIndex);
	            },
	            error: function(jqXHR, exception) {
	                console.log('error');
	            }
	        });
	    }
	    
	    function GenerateData(data, uuid,slideIndex) { 
	    	var slideIndex=slideIndex-1;
	        var str = '';
	        var social = '';
	        localStorage.setItem('obj' + uuid, JSON.stringify(data));
	        $('#galleryTitle').empty();
	        $('#galleryTitle').text(data.content.galleryTitle);
	        var photogalleryCount=(slideIndex+1)+' of '+ data.content.photoCount;
	        $('.div-carousel-index').empty();
	        //$('.div-carousel-index').text(photogalleryCount);
	        social +='<a href="javascript:void(0)"><i class="icons tw-ico" onclick="sharePage(\'https://twitter.com/share?url='+data.content.gallerylink+'&text='+data.content.galleryTitle+' via @htTweets\',500,600);" title="Tweet"></i> </a>';
	        social +='<a href="javascript:void(0)"><i class="icons fb-ico" onclick="sharePage(\'http://www.facebook.com/sharer/sharer.php?u='+data.content.gallerylink+'\',400,350);" title="Facebook Share"></i> </a>'; 
	        social +='<a href="javascript:void(0)"><i class="icons gplus-ico" onclick="sharePage(\'https://plus.google.com/share?url='+data.content.gallerylink+'\',500,450);" title="Google Plus Share"></i> </a>'; 
	        social +='<a href="javascript:void(0)"><i class="icons instagram-ico" onclick="sharePage(\'https://www.linkedin.com/shareArticle?mini=true&url='+data.content.gallerylink+'&title=&summary=&source=\',600,600);" title="Linkdin Share"></i></a>';
	        $("#div-follow-bx").empty();
	        $("#div-follow-bx").append(social); 
	        $.each(data.content.sectionItems, function(i, item) { //alert('i: '+i);
	        	if(i==slideIndex){
	        		$('#imageCaption').empty();
	        		$('#imageCaption').text(item.headLine);
	        		str +='<div class="item active">';
	        		str +='<img src="'+item.wallpaperLarge+'" alt="' + item.headLine+'" />';
	        		str +='<div  class="para-txt">'+item.headLine+'</div>';
	        		str +='</div>';
	        	}
	        	else{
	        		str +='<div class="item">';
	        		str +='<img src="'+item.wallpaperLarge+'" alt="' + item.headLine+'" />';
	        		str +='<div  class="para-txt">'+item.headLine+'</div>';
	        		str +='</div>';
	        	}
	        });
	        //alert('str: '+str);
	        $(".photogallerypopupwindow").empty();
	         $(".photogallerypopupwindow").append(str);
	        var $this = $('#carousel-example-generic');
	         if ($('.carousel-inner .item:first').hasClass('active')) {
	             $this.children('.left.carousel-control').hide();
	         } else if ($('.carousel-inner .item:last').hasClass('active')) {
	             $this.children('.right.carousel-control').hide();
	         } else {
	             $this.children('.carousel-control').show();

	         }
	     }
	   callData(
	    		host+'/Fragment/PortalConfig/Common/modules/mobile/s1/phone/controller/singleObject/getSingleGalleryDetails.jpt?uuid='+uuid+'',
	        uuid);   
	   
}


$(document).ready(function() {
    	
	$('.current-slide').text(1);
var owl = $('#owl-landingphoto');
owl.owlCarousel({
    center: true,
    items:1,
    loop:true,
    margin:0,
    nav:  false,
    onInitialized : function(){ 
        var activeImg = $('.owl-carousel').find('.active').find('img');
        var comment = activeImg.attr('alt');
        //var title = activeImg.attr('title');
        $('#imageCaption').text(comment);
    }
   
});
// total slides count
var i = 1, total = $('.owl-dots div').length;
$('#owl-landingphoto .owl-dot').each(function(){
  $(this).text(i);
  i++;
});
$('.total-slide').text(total);


owl.on('changed.owl.carousel', function() { //alert('heeeelllo '+ $('.owl-dot.active').index());
	var current =  $('.owl-dot.active').text();
	$('.current-slide').text(current);
});

owl.on('translated.owl.carousel', function(event) {
	var photoLink=window.location.href;
	var activeImg = $(this).find('.active').find('img');
    var comment = activeImg.attr('alt');
    $('#imageCaption').text(comment);
    var title = activeImg.attr('title');
    var src = activeImg.attr('src');
    self.COMSCORE && COMSCORE.beacon({
        c1: "2",
        c2: "6035286"
    });
    $.ajax({
        url: '/res/comscore-gallery.xml',
        cache: false,
        type: 'get',
        success: function(data) {
            //console.log(data);                
        }
    });
    ga('send', { 'hitType': 'pageview', 'page': src, 'title': title });
    dataLayer.push ({ 'event' : 'send pageview', 'document_location' : photoLink, 'page_title' : title,'document_page' : src });
});


// custom thumbnail
$('.custom-thumb .thumb').click(function() {
    var clickThumb = $(this).attr('data-number');
	$('.owl-controls .owl-dot:nth-child('+clickThumb+')').trigger('click');
});
  
});

//special photo gallery //

$(document).ready(function() {
 
var owl = $('#spl-owl-photogallery');
owl.owlCarousel({
    center: true,
    items:1,
    loop:true,
    margin:0,
    nav:  false,
   
});
  
});

//whatnow social share

$(document).ready(function() {
    $(".whatshared-btn").click(function(e){
  	//	$(this).next(".shared-social_share").toggleClass("show");
  	
   $(this).next(".shared-social_share").addClass("show").closest(".whatnow-common").siblings().find(".shared-social_share").removeClass("show");
	 e.stopPropagation();
  
  });
  $(".shared-social_share").click(function(e){
   e.stopPropagation();
	});

$(document).click(function(){
   $(".shared-social_share").removeClass("show");
});
  
});


function callData() { 	 
   	$.ajax({
   	type: 'GET',
   	url: 'http://www.hindustantimes.com/ht-feed/weather',
   	async: false,
   	contentType: "application/json",
   	dataType: 'json',
   	success: function(response) {    		
   		var mdata='';
   		
   		for (var i = 0; i < response.weathers.length; i++)
   		{    		
   			mdata=mdata + response.weathers[i].name + ',';    			
   			mdata=mdata + response.weathers[i].main.temp + ',';
   			mdata=mdata + response.weathers[i].main.humidity + ',';
   			mdata=mdata + response.weathers[i].wind.speed + '^';    		    
   		}
   		$('#divAll').html(mdata);
   	},
   	 error: function (xhr, ajaxOptions, thrownError) {
	      console.log(xhr);
   	 }
   	});
   }	 

	function weatherAPI(city) {
		
		setCookie('ht-city',city,30);
		var html = '<div class="headingtwo"><span id="WTemp">-</span>&deg;C</div>';
		
		html += '<span id="WCity">' + city + '</span>,';

		$("#weather").html(html);
		$("#WCity").html(city);
		$("#MCity").html(city);
		
		if (city == 'Bengaluru')
			city = 'Kanija Bhavan';
		
		if (city == 'Dehradun')
			city = 'Dehra Dun';

		if (city == 'Delhi')
			city = 'New Delhi';

		
		var all = $("#divAll").html();

		var res = all.split("^");

		for ( var i = 0; i < res.length; i++) {

			var cityData = res[i];
			var spl = cityData.split(",");

			var fCity = spl[0];


			if (fCity.trim() == city.trim()) {

				var temp=parseFloat(spl[1]);				
				var b= temp.toFixed(0);		
							
				$("#MTemp").html(b);
				$("#WTemp").html(b);
				$("#chumidity").html(spl[2] + '%');
				$("#cwind").html(spl[3] + 'km/h');
			}
		}
	}

callData();



function setCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function checkCookie(mcity) {
    var city=getCookie("ht-city");
    if (city != "") {
    	weatherAPI(city);
    } else {
           setCookie("ht-city", city, 30);
           weatherAPI('New Delhi');
       }
    }

$(document).ready(function(){ 
	checkCookieNewsletter();
	});

checkCookie('New Delhi');
$('.map-container').click(function(){$(this).children('iframe').addClass('clicked')}).mouseleave(function(){
	$(this).find('iframe').removeClass('clicked')});


function createCookie(name,value,days) {
    if (days) {var date = new Date();
        date.setTime(date.getTime()+(days*24*60*60*1000));
        var expires = "; expires="+date.toGMTString();
    }
    else var expires = "";
    document.cookie = name+"="+value+expires+"; path=/";
}
function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}
function checkCookieNewsletter() {  
    var user=readCookie("HtNewsletterCookies");
    if (user != "" && user != null) { 
      $('.fixed_newslettor').hide();  
    }
    else{ 
    	setTimeout(function() 
    			{
    				$('.fixed_newslettor').show(); }, 1000);
    			createIframe();
    			createCookie("HtNewsletterCookies", "ht-newsletter-new", 7);
    	   		}
}

function createIframe()
{ 
	var dateTimeNewsletter = new Date();
	//$('<iframe id="iframenewsletter" name="iframenewsletter"  width="100%" height="105px" scrolling="no"></iframe>').attr('src','http://www.preview.dev.hindustantimes.com:3605/fragment/PortalConfig/www.ns.hindustantimes.com/jpt/newsletter/newsletter-api/Subscrib-Banner.jpt?t='+dateTimeNewsletter).appendTo('.newsletter_fixedrow');
	$('<iframe id="iframenewsletter" name="iframenewsletter"  width="100%" height="105px" scrolling="no"></iframe>').attr('src','http://www.hindustantimes.com/fragment/PortalConfig/www.ns.hindustantimes.com/jpt/newsletter/newsletter-api/Subscrib-Banner.jpt?t='+dateTimeNewsletter).appendTo('.newsletter_fixedrow-story');
}

	
$(".ads-close").click(function(){ 
	
	$(".top-banner").css("display", "none");
	
});	

$(document).ready(function(){
	
	$("#wagon-wheel").css("display","block");
	$("#manhattan").css("display","block");
	$("#run-rate").css("display","block");
	$("#manhattan").css("visibility","hidden");
	 $("#run-rate").css("visibility","hidden");
	 $("#manhattan").css("height","0px");
	 $("#run-rate").css("height","0px");
	 $('a[href="#wagon-wheel"]').on('shown.bs.tab', function (e) {
		 $("#manhattan").css("visibility","hidden");
		 $("#run-rate").css("visibility","hidden");
		 $("#wagon-wheel").css("visibility","visible");
		 $("#manhattan").css("height","0px");
		 $("#run-rate").css("height","0px");
		 $("#manhattan").css("padding","0px");
		 $("#run-rate").css("padding","0px");
		 
	 });
	 $('a[href="#manhattan"]').on('shown.bs.tab', function (e) {
		 
		 $("#wagon-wheel").css("visibility","hidden");
		 $("#run-rate").css("visibility","hidden");
		 $("#manhattan").css("visibility","visible");
		 $("#wagon-wheel").css("height","0px");
		 $("#run-rate").css("height","0px");
		 $("#wagon-wheel").css("padding","0px");
		 $("#run-rate").css("padding","0px");
	 });
	 $('a[href="#run-rate"]').on('shown.bs.tab', function (e) {
		 
		 $("#manhattan").css("visibility","hidden");
		 $("#wagon-wheel").css("visibility","hidden");
		 $("#run-rate").css("visibility","visible");
		 $("#manhattan").css("height","0px");
		 $("#wagon-wheel").css("height","0px");
		 $("#manhattan").css("padding","0px");
		 $("#wagon-wheel").css("padding","0px");
	 });
	 
	
});
